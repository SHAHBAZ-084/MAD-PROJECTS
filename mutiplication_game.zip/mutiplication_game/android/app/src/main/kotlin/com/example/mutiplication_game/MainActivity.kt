package com.example.mutiplication_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
